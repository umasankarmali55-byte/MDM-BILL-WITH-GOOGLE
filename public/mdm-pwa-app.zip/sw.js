/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "658eb206159fccade1edc41ecb2a0649"
  }, {
    "url": "pwa-512x512.png",
    "revision": "242ba59003b456cb53a5602f54a2b3da"
  }, {
    "url": "pwa-192x192.png",
    "revision": "3c0199db460931fc4e95fb9b7c198340"
  }, {
    "url": "index.html",
    "revision": "110444be107d1d4dea5e0bc5a0772f1e"
  }, {
    "url": "icon.svg",
    "revision": "be807545d7a2d0b0ad2374e5eb695fb2"
  }, {
    "url": "favicon.ico",
    "revision": "48d295d45250c9255ccbbfb29c44c18b"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "fb349447e970cc7e5beb1f0f5e2b7968"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/purify.es-Dzkdzyfv.js",
    "revision": null
  }, {
    "url": "assets/index.es-D531Dddq.js",
    "revision": null
  }, {
    "url": "assets/index-QlCgURfI.js",
    "revision": null
  }, {
    "url": "assets/index-4Tq0NEIn.css",
    "revision": null
  }, {
    "url": "assets/html2canvas-CDtQJjj9.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "fb349447e970cc7e5beb1f0f5e2b7968"
  }, {
    "url": "favicon.ico",
    "revision": "48d295d45250c9255ccbbfb29c44c18b"
  }, {
    "url": "icon.svg",
    "revision": "be807545d7a2d0b0ad2374e5eb695fb2"
  }, {
    "url": "pwa-192x192.png",
    "revision": "3c0199db460931fc4e95fb9b7c198340"
  }, {
    "url": "pwa-512x512.png",
    "revision": "242ba59003b456cb53a5602f54a2b3da"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "658eb206159fccade1edc41ecb2a0649"
  }, {
    "url": "manifest.webmanifest",
    "revision": "0a8e75ea4b2cb8440d01bb4dac5cf971"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
