MDM Billing & Attendance — Complete PWA Package
================================================

1. READY-TO-DEPLOY PWA BUILD (Root of this ZIP):
   - index.html
   - manifest.webmanifest
   - sw.js & workbox-*.js (Service Worker for offline use)
   - pwa-192x192.png, pwa-512x512.png, pwa-maskable-512x512.png, apple-touch-icon.png, icon.svg, favicon.ico
   - assets/ (compiled JS & CSS bundles)

   How to run or host immediately:
   - Local test: npx serve . (or python3 -m http.server 8080) and open http://localhost:8080
   - Static hosting: Upload these root files to Netlify Drop, Vercel, Cloudflare Pages, GitHub Pages, or any HTTPS server.
   - Install as App: Open in Chrome/Edge/Android/Safari and click the "Install App" button in the top bar (or Share -> Add to Home Screen on iOS).

2. FULL SOURCE CODE (source/ folder):
   - Includes package.json, vite.config.ts, tsconfig.json, index.html, metadata.json, src/, and public/ icons.
   - To customize and rebuild:
       cd source
       npm install
       npm run dev     (development server on port 3000)
       npm run build   (production PWA build in dist/)
